import datetime
import threading


# threadLock = threading.Lock()

class MyThread(threading.Thread):
    def __init__(self, name, counter):
        threading.Thread.__init__(self)
        self.threadId = counter
        self.name = name
        self.counter = counter

    def run(self):
        print("\nStarting " + self.name)
        # acquire lock to sync thread
        # threadLock.acquire()

        print_date(self.name, self.counter)

        # release lock for the next thread
        # threadLock.release()

        print("Exiting " + self.name)


def print_date(threadName, counter):
    datefields = []
    today = datetime.date.today()
    datefields.append(today)
    print("\n{}[{}]: {}".format(threadName, counter, datefields[0]))


threads = []

# Create new threads
thread1 = MyThread("Thread", 1)
thread2 = MyThread("Thread", 2)

# Start new Threads
thread1.start()
thread2.start()

# Add threads to thread list
threads.append(thread1)
threads.append(thread2)

# Wait for all threads to complete
for thread in threads:
    thread.join()

print("\nExiting the Program!!!")
