# -*- coding: utf-8 -*-

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import Screen

Builder.load_string('''
<OneScreen>
	BoxLayout:
		Button:
			id: one_ask
			text: 'Click me'
			on_release: root.do_something()
		Button:
			id: two_ask
			text: 'Who made this?'
			on_release: root.answer()
''')

class OneScreen(Screen):
	def __init__(self, **kwargs):
		self.author='xxy'
		super(OneScreen, self).__init__(**kwargs)
	def do_something(self):
		self.ids['one_ask'].text='Click me...'
	def answer(self):
		self.ids['two_ask'].text=self.author
	
class TestApp(App):
	def build(self):
		return OneScreen()
		
TestApp().run()