# -*- coding: utf-8 -*-

'''
本脚本接收一个base64编码的字符串输入，将其表示的字节数组转换为16进制字符串形式输出
'''

import base64
import sys

args = sys.argv
if len(args) < 2:
    print("Usage: python base64-to-hex <base64 string>")
    exit(1)

for i in range(len(args) - 1):
    a = args[i + 1]
    # get the bytes
    b = base64.b64decode(a.encode('utf-8'))
    print("input len: %d, result array len: %d" % (len(a), len(b)))
    print('%s\t%s\n' % (a, b.hex()))
