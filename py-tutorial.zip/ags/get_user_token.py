# -*- coding: utf-8 -*-

import csv
import json

import requests

# verification
csv_file = './verification.csv'
url = 'http://10.159.60.33:9080/security/userlogin'
appKey = '89t61cde07y69b6599a42c8d1c020fce'
appId = 'MB-TESTAPP1-0000'
clientId = '356877020056553-08002700DC94'
appVersion = '01.00.00.00000'
# accType=0 表示用手机号登录，99表示用户id登录
accType = 0
loginType = "1"

# ali dev
# csv_file='./ali-dev.csv'
# url = 'http://192.168.170.103:9080/security/userlogin'
# appKey = '2d4e6e535d796909c87ad5f29164c58f'
# appId = 'MB-UWSBC-0000'
# clientId = '356877020056553-08002700DC94'
# appVersion = '01.00.00.00000'
# accType=0 表示用手机号登录，99表示用户id登录
# accType = 99
# loginType = "2"

# southeast asia
# csv_file = './sea.csv'
# url = 'http://uhome-sea.haieriot.net/security/userlogin'
# appKey = 'f50c76fbc8271d361e1f6b5973f54585'
# appId = 'MB-UZHSH-0000'
# clientId = '123'
# appVersion = '99.99.99.99990'
# accType=0 表示用手机号登录，99表示用户id登录
# accType = 99
# loginType = "2"

headers = {
    'Content-Type': 'application/json;charset=UTF-8',
    'clientId': clientId,
    'appVersion': appVersion,
    'appKey': appKey,
    'appId': appId
}

with open(csv_file) as f:
    f_csv = csv.reader(f)
    for row in f_csv:
        body = '{"sequenceId":"87620056570355357690","accType":%d,' \
               '"loginType":"%s","loginId":"%s","password":"%s"}' % (accType,
                                                                     loginType,
                                                                     row[0],
                                                                     row[1])

        r = requests.post(url, data=body, headers=headers)
        # print(r.text)
        # print(r.headers)
        resp = json.loads(r.text)
        if "00000" == resp['retCode']:
            print('%s\t%s\t%s' % (resp['userId'], row[0], r.headers[
                'accessToken']))
        else:
            print('failed to request user token for %s: %s' % (row[0], r.text))
