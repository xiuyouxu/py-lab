# -*- coding: utf-8 -*-

import base64
import hashlib
import json
import time

import pandas as pd
import requests
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA


def split_str(src, size):
    src_len = len(src)
    if src_len <= size:
        return src
    else:
        d = ''
        offset = 0
        while offset + size < src_len:
            d += src[offset:offset + size]
            d += ' '
            offset += size
        if offset < src_len:
            d += src[offset:]

        return d.strip()


def getPublicKey(pubKey):
    encodedKey = base64.b64decode(pubKey.replace(' ', ''))
    return RSA.importKey(encodedKey)


def rsa_split_codec(cipher, mode, data, keySize):
    max_block = 0
    if 0 == mode:
        max_block = int(keySize / 8)
    else:
        max_block = int(keySize / 8) - 11

    out = bytes([])
    offset = 0
    data_len = len(data)
    while offset < data_len:
        if data_len > offset + max_block:
            b = cipher.encrypt(data[offset:offset + max_block])
        else:
            b = cipher.encrypt(data[offset:])
        out = out + b
        offset += max_block

    return out


def publicEncrypt(data, publicKey):
    cipher = PKCS1_OAEP.new(publicKey)
    out = rsa_split_codec(cipher, 1, data.encode('utf-8'),
                          publicKey.size_in_bits())
    return split_str(base64.b64encode(out).decode('utf-8'), 60)


# calc sign
def calc_sign(path, body, systemId, systemKey, ts):
    systemKey = systemKey.strip().replace('"', '')
    body = body.strip().replace(' ', '').replace('\t', '').replace('\r',
                                                                   '').replace(
        '\n', '')
    src = ''
    if url.find('openapi') < 0:
        src += path
    src = src + body + systemId + systemKey + ts

    if url.find('openapi') < 0:
        return hashlib.sha256(src.encode('utf-8')).hexdigest()
    else:
        return hashlib.md5(src.encode('utf-8')).hexdigest()


df = pd.read_csv('./eu.csv', header=None)

url = 'https://uws-gea-euro.haieriot.net/uam/v2/user/loginEmailAcounnt'
appKey = '4fe8b49c445b39df77758bffb7606c80'
appId = 'MB-HEYJOZB-0000'
clientId = '356877020056553-A00000000004'
appVersion = '01.00.00.00000'
pubKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCgzne/QhB6c9jQyFyCLZ5G 5iwbsiqvCg/x4+HOMs4Z+EzByP3RWakP/JkSc7Knq+YYEW1lIa5TY2mGIYWr qzi2iSHqHsSmS/+0d1nn270CZDf+g03foPpwtLQWW3QsmjaHNe+whGbmFYxr LSpJ92Ox795p04Cotv8dEZOveoh3+wIDAQAB'

ts = '%f' % (time.time() * 1000)
idx = ts.find('.')
if idx >= 0:
    ts = ts[:idx]

publicKey = getPublicKey(pubKey)
for i in range(len(df[0])):
    e_email = publicEncrypt(df[0][i], publicKey)
    e_pass = publicEncrypt(df[1][i], publicKey)

    body = '{"email":"%s","password":"%s"}' % (e_email, e_pass)
    print(body)

    headers = {
        'Content-Type': 'application/json;charset=UTF-8',
        'clientId': clientId,
        'appVersion': appVersion,
        'appKey': appKey,
        'appId': appId,
        'sequenceId': '20190312153428000015',
        'timestamp': ts,
        'sign': calc_sign(url[url.find('/', url.find('//') + 2):], body, appId,
                          appKey, ts),
        'language': 'en',
        'timezone': '+8',
        'Content-Encoding': 'utf-8',
        'privacyVersion': 'V1.0.0'
    }
    print(headers)

    r = requests.post(url, data=body, headers=headers)
    print(r.text)
    resp = json.loads(r.text)
    if "00000" == resp['retCode']:
        print('%s\t%s' % (df[0][i], r.headers['accessToken']))
    else:
        print('failed to request user token for %s' % df[0][i])
