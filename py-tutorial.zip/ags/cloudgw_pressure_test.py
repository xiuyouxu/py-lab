# -*- coding: utf-8 -*-

import hashlib
import json
import threading
import time
import uuid

import requests

requests.packages.urllib3.disable_warnings()


# get sha256 digest of src
def sha256_hash(src):
    return hashlib.sha256(src.encode('utf-8')).hexdigest()


# calc sign
def calc_sign(path, body, systemId, systemKey, ts):
    systemKey = systemKey.strip().replace('"', '')
    body = body.strip().replace(' ', '').replace('\t', '').replace('\r',
                                                                   '').replace(
        '\n', '')

    src = path + body + systemId + systemKey + ts
    return sha256_hash(src)


# constants
loop = 1000
n = 1
systemId = 'SV-DEVELOPERSITE-0000'
systemKey = '5d75e1dafb2bd4598ad62dccaf4b2329'
host = '123.103.113.62'
port = 56671
deviceId = 'A00000160001'
token = 'TGT3KSW6KOVCEJUD2B39I8HDFAAYQ0'
deviceKey = '5355Ddf0c51b474397a1561fc468094a'
uPlusID = '101c120024000810180100418000054300000000000000000000000000000000'


class RequestThread(threading.Thread):
    def __init__(self, name):
        threading.Thread.__init__(self)
        self.name = name

    def run(self):
        # print("\nStarting " + self.name)

        ts = '%f' % (time.time() * 1000)
        idx = ts.find('.')
        if idx >= 0:
            ts = ts[:idx]

        seqId = str(uuid.uuid1()).replace('-', '')

        path = '/cloudgw/v1/dev/property'
        url = 'https://' + host + ':' + str(port) + path

        # src = deviceId + uPlusID + deviceKey + ts
        # devSign = sha256_hash(src)

        payload = {
            'deviceId': deviceId,
            'propertys': [{
                'name': 'temp',
                'value': '25'
            }]
            # 'uPlusID':uPlusID,
            # 'devSign':devSign,
            # 'online':True
        }

        body = json.dumps(payload)
        sign = calc_sign(path, body, systemId, systemKey, ts)

        headers = {
            'Content-Type': 'application/json;charset=UTF-8',
            'timestamp': ts,
            'systemId': systemId,
            'sequenceId': seqId,
            'sign': sign
        }

        r = requests.post(url, data=body, headers=headers, verify=False)

    # print(r.text)

    # print("Exiting "+self.name)


stat_file = open('./stats.txt', 'w')
for j in range(loop):
    start_time = time.time()

    threads = []

    # Create new threads
    for i in range(n):
        t = RequestThread("Thread%d" % i)
        t.start()
        threads.append(t)

    # Wait for all threads to complete
    for thread in threads:
        thread.join()

    end_time = time.time()
    stat_file.write("time elapsed: %f, %f, %f\n" % (
    start_time, end_time, (end_time - start_time)))

stat_file.close()

print("\nExiting the Program!!!")
