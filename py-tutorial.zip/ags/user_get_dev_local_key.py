# -*- coding: utf-8 -*-
import base64
import json
import ssl
import time

import paho.mqtt.client as mqtt

# constants
token = 'TGT2ZFFO2W64HGJA2G10YVSEM14OX0'
devId = '04FA836D532A'
mqtt_username = '0111016034'
mqtt_passwd = 'a498cc03f04bca693467e822c6008296'

heartbeat_payload = {"sn": 0, "duration": 0, "tokens": [token]}
data = {"sn": "7acce5a6ba8c4ea099a6fc22950127bc",
        "dev": devId,
        "flag": 1}
user_get_dev_local_key_payload = {"type": "devLocalkey",
                         "data": str(base64.b64encode(json.dumps(
                             data).encode('utf-8')), 'utf-8'),
                         "tokens": [token]}


def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))
    if rc == 0:
        # subscribe
        client.subscribe("Client/%s/Business/Down" % token, 1)
        # client.subscribe("User/%s/Push/Event" % token, 1)
        time.sleep(3)

        client.publish('Client/%s/HeartBeat' % token,
                       json.dumps(heartbeat_payload))
        time.sleep(3)
        client.publish('Client/%s/Business/Up' % token,
                       json.dumps(user_get_dev_local_key_payload))
    # time.sleep(5)
    else:
        client.disconnect()


def on_message(client, userdata, msg):
    payload = msg.payload.decode('utf-8')
    print(msg.topic + " " + payload)
    data = json.loads(payload)['data']
    print("data: " + base64.b64decode(data).decode('utf-8'))
    if ("Client/%s/Business/Down" % token) == msg.topic:
        client.disconnect()

    # if ("User/%s/Push/Event" % token) == msg.topic:
    #     client.disconnect()


client = mqtt.Client('', True, None, mqtt.MQTTv31)
client.username_pw_set(mqtt_username, mqtt_passwd)
client.on_connect = on_connect
client.on_message = on_message
# context=jksfile2context.jksfile2context('./client.trust.jks', '123456')
# ks = jks.KeyStore.load('./client.trust.jks', '123456')
# cert_bytes = ks.certs['gw.haier.net'].cert
# ssl.DER_cert_to_PEM_cert(cert_bytes)
context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
# context.check_hostname = False
# context.load_cert_chain('./client.trust.pem', password='123456')
client.tls_set_context(context)
# # client.tls_set('./ags.server.pem')
# client.tls_insecure_set(True)

# 修改hosts文件将域名gw.haier.net指向该ip
client.connect("10.159.60.28", 56783, 60)

# Blocking call that processes network traffic, dispatches callbacks and
# handles reconnecting.
# Other loop*() functions are available that give a threaded interface and a
# manual interface.
client.loop_forever()
