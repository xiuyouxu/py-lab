# -*- coding: utf-8 -*-
import logging
import random
import time

from kazoo.client import KazooClient
from kazoo.client import KazooState

# enable logging
logging.basicConfig()

zk = KazooClient(hosts="127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183")
zk.start()


def my_listener(state):
    if state == KazooState.LOST:
        print("connection lost")
    elif state == KazooState.SUSPENDED:
        print("connection suspended")
    else:
        print("connection", state)


zk.add_listener(my_listener)
#
# children = zk.get_children("/onlineDevs")
# # print(children)
# print(len(children))

cnt = 0
avg = 0
sum = 0
max_node_num = 1000000
start_time = time.time()
all_created = False
while True:
    t1 = time.time()
    num = random.randint(0, max_node_num)
    node = "/onlineDevs/dev-%d" % num
    stat = zk.exists(node)
    t2 = time.time()
    sum += (t2 - t1)
    cnt += 1
    avg = sum / cnt
    if cnt % 100 == 0:
        children = zk.get_children("/onlineDevs")
        # print(children)
        print("total children nodes: %d" % len(children))
        if max_node_num == len(children) and not all_created:
            all_created = True
            end_time = time.time()
            print("===================creating %d nodes needed time: %f" % (
                max_node_num, end_time - start_time))

        print("avg time for checking node existence: %f, cnt=%d" % (avg, cnt))
        if stat is not None:
            print("node [%s] existence: True" % node)
        else:
            print("node [%s] existence: False" % node)
