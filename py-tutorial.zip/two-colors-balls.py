# -*- coding: utf-8 -*-

import random

# red: 1-33, blue: 1-16
# (33*32*31*30*29*28/6!)*16=17721088
# 17721088/(3*52)=113596.71794871794871794871794872

# constants
max_times = 1000


# sort list a
def sort(a):
    if a is None:
        return
    size = len(a)
    for i in range(size):
        for j in range(i + 1, size):
            if a[i] > a[j]:
                t = a[i]
                a[i] = a[j]
                a[j] = t


def compare(target, actual):
    if target is None and actual is None:
        return True
    if target is None and actual is not None:
        return False
    if target is not None and actual is None:
        return False

    t_len = len(target)
    a_len = len(actual)
    if t_len != a_len:
        return False

    for i in range(t_len):
        if target[i] != actual[i]:
            return False

    return True


total = 0
for loop in range(max_times):
    count = 0
    while True:
        red_balls = []
        for i in range(33):
            red_balls.append(i + 1)
        for i in range(6):
            r = random.randint(0, 32)
            t = red_balls[r]
            red_balls[r] = red_balls[i]
            red_balls[i] = t

        target = red_balls[0:7]
        target.append(random.randint(1, 16))

        red_balls = []
        for i in range(33):
            red_balls.append(i + 1)
        for i in range(6):
            r = random.randint(0, 32)
            t = red_balls[r]
            red_balls[r] = red_balls[i]
            red_balls[i] = t

        actual = red_balls[0:7]
        actual.append(random.randint(1, 16))

        count += 1

        # if count % 10000 == 0:
        # print('tried %d times' % count)
        # print('target %s, actual %s' % (target, actual))

        # sort before compare
        sort(target)
        sort(actual)
        if compare(target, actual):
            print('after %d times, got the big prize!' % count)
            print('the winner lottery number is: %s' % target)
            total += count
            break

print('avg times for wining: %f' % (total / max_times))
