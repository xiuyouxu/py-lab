import socket

import serialization
from OpenSSL import SSL

dst = ('10.159.60.27', 56671)
ctx = SSL.Context(SSL.SSLv23_METHOD)
s = socket.create_connection(dst)
s = SSL.Connection(ctx, s)
s.set_connect_state()
s.set_tlsext_host_name(dst[0].encode('utf8'))

s.sendall('HEAD / HTTP/1.0\n\n')
s.recv(16)

certs = s.get_peer_cert_chain()
for pos, cert in enumerate(certs):
    print(cert.to_cryptography().public_bytes(serialization.Encoding.PEM))
# print("Certificate #" + str(pos))
# for component in cert.get_subject().get_components():
# print("Subject %s: %s" % (component))
# print("notBefore:" + cert.get_notBefore())
# print("notAfter:" + cert.get_notAfter())
# print("version:" + str(cert.get_version()))
# print("sigAlg:" + cert.get_signature_algorithm())
# print("digest:" + cert.digest('sha256'))
