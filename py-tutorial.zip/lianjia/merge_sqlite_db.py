# -*- coding: utf-8 -*-

import sqlite3

districts = ['dongcheng', 'xicheng', 'chaoyang', 'haidian', 'fengtai',
             'shijingshan', 'tongzhou', 'changping', 'daxing', 'mentougou']

command = '''create table if not exists house (
            id TEXT primary key UNIQUE,
            price float,
            unitprice float,
            community TEXT,
            district TEXT,
            region TEXT,
            area TEXT,
            url TEXT,
            huxing TEXT,
            louceng TEXT,
            jianmian TEXT,
            hugou TEXT,
            taomian TEXT,
            jianxing TEXT,
            chaoxiang TEXT,
            jiangou TEXT,
            zhuangxiu TEXT,
            tihu TEXT,
            gongnuan TEXT,
            dianti TEXT,
            chanquan TEXT,
            guapai TEXT,
            quanshu TEXT,
            shangci TEXT,
            yongtu TEXT,
            nianxian TEXT,
            chanshu TEXT,
            diya TEXT,
            fangben TEXT
)'''

conn = sqlite3.connect('lianjia-house.db')
conn.text_factory = str
cu = conn.cursor()
cu.execute(command)

duplicated = 0
for district in districts:
    db = "lianjia-house-%s.db" % district
    print("merging db: %s" % db)
    sub_conn = sqlite3.connect(db)
    sub_conn.text_factory = str
    sub_cu = sub_conn.cursor()
    sub_cu.execute("select * from house")
    rs = sub_cu.fetchall()
    for row in rs:
        try:
            row = list(row)
            row[1] = float(row[1])
            row[2] = float(row[2])
            row = tuple(row)
            cu.execute(
                r"insert into house values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                row)
        except Exception as e:
            duplicated += 1
            s=str(row)
            print(s.encode('utf-8'))
            print(e)
conn.commit()

print("duplicated %d" % duplicated)
