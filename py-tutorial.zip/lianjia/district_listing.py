import sqlite3

db = './crawlered-data/lianjia-house.db'

districts = ['dongcheng', 'xicheng', 'chaoyang', 'haidian', 'fengtai',
             'shijingshan', 'tongzhou', 'changping', 'daxing', 'mentougou']

conn = sqlite3.connect(db)
conn.text_factory = str
cu = conn.cursor()

for district in districts:
    cu.execute('select count(1) from house where district=\'%s\'' % district)
    r = cu.fetchone()
    print("%s\t%d" % (district, r[0]))
