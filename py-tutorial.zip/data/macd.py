# -*- coding: utf-8 -*-
import os
import sqlite3
import sys

import stock_util
import constants

import matplotlib

matplotlib.rc('font', family='SimHei')

import matplotlib.pyplot as plt
import pandas as pd

try:
    plt.style.use('ggplot')

    code = 'sh000001'

    if len(sys.argv) > 1:
        code = sys.argv[1]
    print("target code {0}".format(code))

    db = '{0}/{1}.db'.format(constants.data_dir, code)

    # check whether data exists
    if os.path.exists(db):
        conn = sqlite3.connect(db)
        df = pd.read_sql("select * from `{0}` order by `date` desc limit {"
                         "1}".format(code, 365 * 2), con=conn)
        df = df[::-1]

        # df = pd.read_csv('sh000001.csv', encoding='utf-8')
        # df = df.tail(500)
        # print(df)

        fig, ax1 = plt.subplots()

        x = df['date']

        color = 'tab:red'
        ax1.set_ylabel('price', color=color)
        # close price
        # ax1.plot(x, df['close'], label='Close')

        # exponential weighted moving average
        dif = df['close'].ewm(span=12).mean() - df['close'].ewm(span=26).mean()
        dea = dif.ewm(span=9).mean()
        ax1.plot(x, dif, label='DIF')
        ax1.plot(x, dea, label='DEA')

        ax1.tick_params(axis='y', labelcolor=color)
        # ax1.legend(loc='best')

        ax2 = ax1.twinx()
        color = 'tab:cyan'
        ax2.set_ylabel('volume', color=color)
        ax2.plot(x, df['volume'], label='Volume', color=color)
        ax2.tick_params(axis='y', labelcolor=color)
        # ax2.legend(loc='best')

        fig.legend(loc=1)
        fig.tight_layout()
        plt.xticks(range(0, len(x), 50))
        stock_name = stock_util.get_stock_name(code)
        print("stock {0} name: {1}".format(code, stock_name))
        plt.title('[{0}-{1}] DIF, DEA and Volume'.format(code, stock_name))
        mng = plt.get_current_fig_manager()
        # mng.frame.Maximize(True)
        # mng.window.showMaximized()
        # mng.full_screen_toggle()
        mng.window.state('zoomed')
        plt.show()
    else:
        print(
            "no database file [{0}] found, please execute ma.py first to fetch "
            "all history data".format(db))
        exit(1)
except Exception as e:
    print(e)
