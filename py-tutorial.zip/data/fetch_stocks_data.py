import subprocess

cmd = 'C:/Python/Python37/python.exe'
stocks_file = './stocks.txt'

f = open(stocks_file, encoding='UTF-8')
try:
    while True:
        line = f.readline()
        if line:
            line = line.strip('\n')
            print("fetching data for stock {0}".format(line))
            exec_result = subprocess.call([cmd, './ma.py', line, '1'])
            print("fetching result {0}".format(exec_result))

        else:
            print("file EOF:", stocks_file)
            break
finally:
    f.close()
