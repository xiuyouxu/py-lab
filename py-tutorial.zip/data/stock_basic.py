import sqlite3

import tushare as ts

token = 'f9f8d618c5febe16be905c4623b2472621b3a5ff28d84bed921e7cd1'

ts.set_token(token)
pro = ts.pro_api()

print("fetching all stocks data...")
stock_list = pro.stock_basic()
print("all stocks data fetched...")

conn = sqlite3.connect('./stock_data/stocks.db')
# ts_code|symbol|name|area|industry|market|list_date
# 600519.SH|600519|贵州茅台|贵州|白酒|主板|20010827
stock_list.to_sql(name='stocks', con=conn, if_exists='replace', index=False)
print("all stocks data saved to stocks.db, exiting...")
conn.close()
