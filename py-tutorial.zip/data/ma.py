# -*- coding: utf-8 -*-
import datetime
import os
import sqlite3
import sys

import matplotlib

import constants
import stock_util

matplotlib.rc('font', family='SimHei')

import matplotlib.pyplot as plt
import pandas as pd
import tushare as ts
import pyecharts.options as opts
from pyecharts.charts import Line, Bar, Grid, Kline

import logging

logging.basicConfig(format='%(asctime)s - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S', level=logging.DEBUG)

try:
    plt.style.use('ggplot')

    code = 'sh000001'
    download = True
    plot_img = True

    if not os.path.exists(constants.data_dir):
        os.mkdir(constants.data_dir)

    logging.debug("sys.argv: {0}".format(sys.argv))
    if len(sys.argv) > 1:
        code = sys.argv[1]
    logging.debug("target code {0}".format(code))

    if len(sys.argv) > 2:
        download = sys.argv[2] == '1'
    logging.debug("download latest data: {0}".format(download))

    # if len(sys.argv) > 3:
    #     plot_img = sys.argv[3] == '1'
    # logging.debug("plot image {0}".format(plot_img))

    conn = sqlite3.connect('{0}/{1}.db'.format(constants.data_dir, code))
    cu = conn.cursor()

    # check whether the table exists or is empty
    table_exists = False
    table_empty = False
    cu.execute("SELECT count(1) FROM sqlite_master WHERE type='table' AND "
               "name='%s'" % code)
    record = cu.fetchone()
    table_exists = record[0] > 0
    if table_exists:
        cu.execute('select count(1) from `{0}`'.format(code))
        record = cu.fetchone()
        table_empty = record[0] == 0
        if table_empty:
            cu.execute("drop table `{0}`".format(code))

    # f = '{0}/{1}.csv'.format(data_dir, code)
    today = datetime.date.today()
    # two_years_ago = today - timedelta(days=365 * 2)
    # today = today.strftime('%Y-%m-%d')
    # two_years_ago = two_years_ago.strftime('%Y-%m-%d')

    if not table_exists or table_empty:
        logging.debug("first running, fetching all history data before today")

        # if os.path.exists(f):
        #     os.remove(f)

        df = ts.get_hist_data(code)
        # df['date'] = df.index
        df.insert(loc=0, column='date', value=df.index)
        df = df[::-1]
        # df.to_csv(f, index=False)

        df.to_sql(name=code, con=conn, if_exists='append', index=False)
    else:
        logging.debug("history data fetched already, possibly updating it")
        cu.execute(
            'select `date` from `{0}` order by `date` desc limit 1'.format(
                code))
        record = cu.fetchone()
        last_trading_date = datetime.datetime.strptime(record[0],
                                                       '%Y-%m-%d').date()
        last_trading_date = last_trading_date + datetime.timedelta(days=1)

        if download and last_trading_date < today:
            logging.debug("fetching data after {0}".format(last_trading_date))
            df = ts.get_hist_data(code,
                                  start=last_trading_date.strftime('%Y-%m-%d'))
            df.insert(loc=0, column='date', value=df.index)
            logging.debug("fetched data: {0}".format(df))
            df.to_sql(name=code, con=conn, if_exists='append', index=False)

        df = pd.read_sql("select * from `{0}` order by `date` desc limit {"
                         "1}".format(code, 365 * 2), con=conn)
        # logging.debug("selected data: {0}".format(df))
        df = df[::-1]

    # df = pd.read_csv('sh000001.csv', encoding='utf-8')
    # df = df.tail(500)
    # logging.debug(df)

    stock_name = stock_util.get_stock_name(code)
    title = '[{}-{}]'.format(code, stock_name)

    x = df['date']
    ma_50 = df['close'].ewm(span=50).mean()
    ma_200 = df['close'].ewm(span=200).mean()
    data = df[['open', 'close', 'low', 'high']].values.tolist()

    # output html charts
    x_axis = x.tolist()
    kline = (
        Kline()
            .add_xaxis(xaxis_data=x_axis)
            .add_yaxis(
            series_name=title,
            y_axis=data,
            itemstyle_opts=opts.ItemStyleOpts(color="#ec0000",
                                              color0="#00da3c"),
        )
            .set_global_opts(
            title_opts=opts.TitleOpts(
                title=title,
                subtitle="Candlestick, MA50, MA200 and Volume",
            ),
            legend_opts=opts.LegendOpts(pos_top=10, pos_left='center'),
            xaxis_opts=opts.AxisOpts(type_="category"),
            yaxis_opts=opts.AxisOpts(
                is_scale=True,
                splitarea_opts=opts.SplitAreaOpts(
                    is_show=True, areastyle_opts=opts.AreaStyleOpts(opacity=1)
                ),
            ),
            datazoom_opts=[
                opts.DataZoomOpts(
                    is_show=False,
                    type_="inside",
                    xaxis_index=[0, 1],
                    range_start=90,
                    range_end=100,
                ),
                opts.DataZoomOpts(
                    is_show=True,
                    xaxis_index=[0, 1],
                    type_="slider",
                    pos_top="90%",
                    range_start=90,
                    range_end=100,
                ),
            ],
            tooltip_opts=opts.TooltipOpts(
                trigger="axis",
                axis_pointer_type="cross",
                background_color="rgba(245, 245, 245, 0.8)",
                border_width=1,
                border_color="#ccc",
                textstyle_opts=opts.TextStyleOpts(color="#000"),
            ),
            visualmap_opts=opts.VisualMapOpts(
                is_show=False,
                dimension=2,
                series_index=5,
                is_piecewise=True,
                pieces=[
                    {"value": 1, "color": "#ec0000"},
                    {"value": -1, "color": "#00da3c"},
                ],
            ),
            axispointer_opts=opts.AxisPointerOpts(
                is_show=True,
                link=[{"xAxisIndex": "all"}],
                label=opts.LabelOpts(background_color="#777"),
            ),
            brush_opts=opts.BrushOpts(
                x_axis_index="all",
                brush_link="all",
                out_of_brush={"colorAlpha": 0.1},
                brush_type="lineX",
            ),
        )
    )

    line = (
        Line()
            .add_xaxis(xaxis_data=x_axis)
            .add_yaxis(
            series_name="MA50",
            y_axis=ma_50.tolist(),
            is_smooth=True,
            is_hover_animation=False,
            linestyle_opts=opts.LineStyleOpts(width=3, opacity=0.5),
            label_opts=opts.LabelOpts(is_show=False),
            symbol='none'
        )
            .add_yaxis(
            series_name="MA200",
            y_axis=ma_200.tolist(),
            is_smooth=True,
            is_hover_animation=False,
            linestyle_opts=opts.LineStyleOpts(width=3, opacity=0.5),
            label_opts=opts.LabelOpts(is_show=False),
            symbol='none'
        )
            .set_global_opts(xaxis_opts=opts.AxisOpts(type_="category"))
    )

    bar = (
        Bar()
            .add_xaxis(xaxis_data=x_axis)
            .add_yaxis(
            series_name="Volume",
            yaxis_data=df['volume'].tolist(),
            xaxis_index=1,
            yaxis_index=1,
            label_opts=opts.LabelOpts(is_show=False),
        )
            .set_global_opts(
            xaxis_opts=opts.AxisOpts(
                type_="category",
                is_scale=True,
                grid_index=1,
                boundary_gap=False,
                axisline_opts=opts.AxisLineOpts(is_on_zero=False),
                axistick_opts=opts.AxisTickOpts(is_show=False),
                splitline_opts=opts.SplitLineOpts(is_show=False),
                axislabel_opts=opts.LabelOpts(is_show=False),
                split_number=20,
                min_="dataMin",
                max_="dataMax",
            ),
            yaxis_opts=opts.AxisOpts(
                grid_index=1,
                is_scale=True,
                split_number=2,
                axislabel_opts=opts.LabelOpts(is_show=False),
                axisline_opts=opts.AxisLineOpts(is_show=False),
                axistick_opts=opts.AxisTickOpts(is_show=False),
                splitline_opts=opts.SplitLineOpts(is_show=False),
            ),
            legend_opts=opts.LegendOpts(is_show=False),
        )
    )

    # Kline And Line
    overlap_kline_line = kline.overlap(line)

    # Grid Overlap + Bar
    grid_chart = Grid(init_opts=opts.InitOpts(width="1400px",
                                              height="600px",
                                              page_title=title))
    grid_chart.add(
        overlap_kline_line,
        grid_opts=opts.GridOpts(pos_left="10%", pos_right="8%", height="50%"),
    )
    grid_chart.add(
        bar,
        grid_opts=opts.GridOpts(
            pos_left="10%", pos_right="8%", pos_top="70%", height="16%"
        ),
    )
    grid_chart.render("{}/{}.html".format(constants.data_dir, code))

    # if not plot_img:
    #     logging.debug("not plot image, exiting...")
    #     exit(0)
    #
    # fig, ax1 = plt.subplots()
    #
    # color = 'tab:red'
    # ax1.set_ylabel('price', color=color)
    # # close price
    # ax1.plot(x, df['close'], label='Close')
    # # simple moving average
    # # ax1.plot(x,df['close'].rolling(50).mean(), label='MA 50 days')
    # # ax1.plot(x,df['close'].rolling(200).mean(), label='MA 200 days')
    #
    # # exponential weighted moving average
    # ax1.plot(x, ma_50, label='MA 50 days')
    # ax1.plot(x, ma_200, label='MA 200 days')
    #
    # ax1.tick_params(axis='y', labelcolor=color)
    # # ax1.legend(loc='best')
    #
    # ax2 = ax1.twinx()
    # color = 'tab:cyan'
    # ax2.set_ylabel('volume', color=color)
    # ax2.plot(x, df['volume'], label='Volume', color=color)
    # # ax2.bar(x, df['volume'], label='Volume', width=0.35, color=color)
    # ax2.tick_params(axis='y', labelcolor=color)
    # # ax2.legend(loc='best')
    #
    # fig.legend(loc=1)
    # fig.tight_layout()
    # plt.xticks(range(0, len(x), 50))
    # logging.debug("stock {0} name: {1}".format(code, stock_name))
    # plt.title(title)
    # mng = plt.get_current_fig_manager()
    # # mng.frame.Maximize(True)
    # # mng.window.showMaximized()
    # # mng.full_screen_toggle()
    # mng.window.state('zoomed')
    # plt.show()

except Exception as e:
    logging.debug(e)
