import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
import tushare as ts

# sb.set_style("whitegrid")  # 绘图样式

mpl.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

ts.set_token('f9f8d618c5febe16be905c4623b2472621b3a5ff28d84bed921e7cd1')  # 请注册使用自己的TS key，这个key没用
pro = ts.pro_api()

stock_code = '600519.SH'  # 需要查阅的股票代码，前边是代码，后边是市场，详见Tushare说明


def get_data(x):  # 取得股票数据的函数，包括股票价格，复权信息，基本的基本面信息
    df_day = pro.daily(ts_code=x)  # 取日线行情，最新限制，只能取4000条，需要再多，用循环按日期取多次
    df_adj_factor = pro.adj_factor(ts_code=x)  # 取复权因子
    df_basic = pro.daily_basic(ts_code=x)  # 取基本面信息
    del df_basic['close']  # 去掉冗余信息
    # 合并数据并返回
    df = df_day.merge(right=df_adj_factor, how='left',
                      on=['ts_code', 'trade_date'])
    df = df.merge(right=df_basic, how='left', on=['ts_code', 'trade_date'])
    return df


# def get_name(x):  # 返回股票名字
#     df = pro.namechange(ts_code=x, fields='name')
#     return df.iloc[0, 0]


def str_to_date(str):  # 转换YYYYMMDD到YYYY-MM-DD
    if len(str) == 8:
        return str[0:4] + '-' + str[4:6] + '-' + str[6:8]  # 老人家表示知道format但就爱那么干
    else:
        return str


# title = stock_code + ' - ' + get_name(stock_code)  # 显示标题
title = stock_code  # 显示标题

df = get_data(stock_code)  # 取得数据

df['trade_date'] = df['trade_date'].apply(
    str_to_date)  # 转换trade_date到日期类型，并设置为索引
df['trade_date'] = pd.to_datetime(df['trade_date'])
df.set_index('trade_date', inplace=True)
# 按季度做重采样，并计算收盘价以及基本面信息
period_type = 'Q'  # Q季度，也可以用M月
df_quote = df.resample(period_type).last()
df_quote['close'] = df['close'].resample(period_type).last()
df_quote['PE'] = df['pe'].resample(period_type).last()
df_quote['PB'] = df['pb'].resample(period_type).last()
df_quote['PS'] = df['ps'].resample(period_type).last()
df_quote['adj_factor'] = df['adj_factor'].resample(period_type).last()
df_quote = df_quote[df_quote['ts_code'].notnull()]
df_quote['Price'] = df_quote['close'] * df_quote['adj_factor']  # 计算复权价

df_quote.reset_index(inplace=True)  # 重置索引
df = df_quote.loc[:, ['trade_date', 'PE', 'PB', 'PS', 'Price']]  # 取需要的列

df.plot(kind='line', x='trade_date',
        figsize=(15, 13), title=title,
        fontsize=20, subplots=True, logy=False)
plt.show()