# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np

plt.figure()
N = 5
menMeans = (20, 35, 30, 35, 27)
menStd = (2, 3, 4, 1, 2)
width = 0.35  # the width of the bars
womenMeans = (25, 32, 34, 20, 25)
womenStd = (3, 5, 2, 3, 3)
ind = np.arange(N)
plt.ylim(0.0, 65.0)
plt.bar(ind, menMeans, width, color='r', yerr=menStd, label='Men means')
plt.bar(ind + width, womenMeans, width, color='y', yerr=womenStd,
        label='Women means')
plt.ylabel('Bar plot')

x = np.linspace(0, N)
y = np.sin(x)
axes2 = plt.twinx()
axes2.plot(x, y, color='k', label='Sine')
axes2.set_ylim(-1, 1)
axes2.set_ylabel('Line plot')

mng = plt.get_current_fig_manager()
# mng.frame.Maximize(True)
# mng.window.showMaximized()
# mng.full_screen_toggle()
mng.window.state('zoomed')
plt.show()
