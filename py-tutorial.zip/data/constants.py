# -*- coding: utf-8 -*-

"""
constants
"""


# directory contains all data files
data_dir = './stock_data'

# index code and name dictionary
index_dict = {
    'sh000001': '上证指数',
    'sh000905': '中证500'
}
