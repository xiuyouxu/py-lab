# -*- coding: utf-8 -*-

import pyecharts.options as opts
from pyecharts.charts import Line

x = [i for i in range(12)]

line1 = Line()
line1.add_xaxis(x)
line1.add_yaxis("a", [i for i in range(12)])
line1.set_global_opts(title_opts=opts.TitleOpts(title="test1"))
line1.extend_axis(yaxis=opts.AxisOpts(axislabel_opts=opts.LabelOpts(
    formatter="{value}"), interval=5, min_=2000))

line2 = Line()
line2.add_xaxis(x)
line2.add_yaxis("b", [i for i in range(2000, 2010)], yaxis_index=1)
line2.set_global_opts(title_opts=opts.TitleOpts(title="test2"))

line1.overlap(line2)
line1.render(path="line-example.html")

# bar = (
#     Bar()
#         .add_xaxis(Faker.months)
#         .add_yaxis("蒸发量", [i for i in range(12)])
#         .add_yaxis("降水量", [i for i in range(110, 122)])
#         .extend_axis(
#         yaxis=opts.AxisOpts(
#             axislabel_opts=opts.LabelOpts(formatter="{value} °C"),
#             interval=5, min_=500
#         )
#     )
#         .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
#         .set_global_opts(
#         title_opts=opts.TitleOpts(title="Overlap-bar+line（双 Y 轴）"),
#         yaxis_opts=opts.AxisOpts(
#             axislabel_opts=opts.LabelOpts(formatter="{value} ml")
#         ),
#     )
# )
#
# line = Line().add_xaxis(Faker.months).add_yaxis("平均温度",
#                                                 [i for i in range(500, 512)],
#                                                 yaxis_index=1)
# bar.overlap(line)
# bar.render(path="line-example.html")
