# -*- coding: utf-8 -*-
import json
import os
import sqlite3

import requests

import constants

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'}

market_dict = {
    '6': 'sh',
    '0': 'sz'
}

command = '''create table if not exists pe_and_ap (
        `date` TEXT,
        pe REAL,
        adjusted_price REAL
)'''

stock_conn = sqlite3.connect("{0}/stocks.db".format(constants.data_dir))

try:
    stock_cu = stock_conn.cursor()
    stock_cu.execute("select symbol from stocks")
    r = stock_cu.fetchall()
    if r is not None and len(r) > 0:
        for symbol in r:
            code = symbol[0]
            db = "{0}/pe/{1}-pe-ap.db".format(constants.data_dir, code)
            if os.path.exists(db):
                os.remove(db)
            pe_conn = sqlite3.connect(db)

            try:
                market = market_dict.get(code[0])
                url = 'https://eniu.com/chart/pea/%s%s' % (market, code)
                r = requests.get(url, headers=headers)
                txt = r.content.decode('utf-8')
                data = json.loads(txt)
                pe_cu = pe_conn.cursor()
                pe_cu.execute(command)

                date = data['date']
                pe_ttm = data['pe_ttm']
                price = data['price']

                if len(date) > 0:
                    for i in range(len(date)):
                        t = [date[i], pe_ttm[i], price[i]]
                        t = tuple(t)
                        insert_cmd = r"insert into pe_and_ap values(?,?,?)"
                        pe_cu.execute(insert_cmd, t)

                    pe_conn.commit()

            except Exception as e:
                print(e)
            finally:
                if pe_conn is not None:
                    pe_conn.close()

except Exception as e:
    print(e)
finally:
    if stock_conn is not None:
        stock_conn.close()
