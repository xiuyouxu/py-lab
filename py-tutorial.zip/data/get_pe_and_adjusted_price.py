# -*- coding: utf-8 -*-
import json

import matplotlib

matplotlib.rc('font', family='SimHei')

import matplotlib.pyplot as plt
import requests

import stock_util

plt.style.use('ggplot')

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'}

plot_size = 730
code = '000651'
market_dict = {
    '6': 'sh',
    '0': 'sz'
}
market = market_dict.get(code[0])

url = 'https://eniu.com/chart/pea/%s%s' % (market, code)

r = requests.get(url, headers=headers)
txt = r.content.decode('utf-8')
print("response status: %d" % (r.status_code))
# keys: date, pe_ttm, price
# ttm: Trailing 12 Months
data = json.loads(txt)

fig, ax1 = plt.subplots()

x = data['date']
print("received data size: %d" % (len(x)))
x = x[-plot_size:-1]

color = 'tab:red'
ax1.set_ylabel('pe_ttm', color=color)
ax1.plot(x, data['pe_ttm'][-plot_size:-1], label='PE')

ax1.tick_params(axis='y', labelcolor=color)

ax2 = ax1.twinx()
color = 'tab:cyan'
ax2.set_ylabel('adjusted price', color=color)
ax2.plot(x, data['price'][-plot_size:-1], label='Adjusted Price', color=color)
ax2.tick_params(axis='y', labelcolor=color)

fig.legend(loc=1)
fig.tight_layout()
plt.xticks(range(0, len(x), 50))
stock_name = stock_util.get_stock_name(code)
print("stock {0} name: {1}".format(code, stock_name))
plt.title('[{0}-{1}] PE and Adjusted Price'.format(code, stock_name))
mng = plt.get_current_fig_manager()
# mng.frame.Maximize(True)
# mng.window.showMaximized()
# mng.full_screen_toggle()
mng.window.state('zoomed')
plt.show()
