# import matplotlib.pyplot as plt
# import mpld3
# import numpy as np
#
# fig, ax = plt.subplots(subplot_kw=dict(axisbg='#EEEEEE'))
# N = 100
#
# scatter = ax.scatter(np.random.normal(size=N),
#                      np.random.normal(size=N),
#                      c=np.random.random(size=N),
#                      s=1000 * np.random.random(size=N),
#                      alpha=0.3,
#                      cmap=plt.cm.jet)
# ax.grid(color='white', linestyle='solid')
#
# ax.set_title("Scatter Plot (with tooltips!)", size=20)
#
# labels = ['point {0}'.format(i + 1) for i in range(N)]
# tooltip = mpld3.plugins.PointLabelTooltip(scatter, labels=labels)
# mpld3.plugins.connect(fig, tooltip)
#
# mpld3.show()


import matplotlib.pyplot as plt
import mpld3
import numpy as np

f, ax = plt.subplots()
x1 = np.array([0, 100], int)
x2 = np.array([10, 110], int)
y = np.array([0, 100], int)

line = ax.plot(x1, y)
mpld3.plugins.connect(f,
                      mpld3.plugins.LineLabelTooltip(line[0], label='label 1'))

line = ax.plot(x2, y)
mpld3.plugins.connect(f,
                      mpld3.plugins.LineLabelTooltip(line[0], label='label 2'))

mpld3.show()
