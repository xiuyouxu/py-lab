# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
from math import sin

try:
    x = range(1, 20)
    y = [sin(a) for a in x]
    c = ['r' if b >= 0 else 'b' for b in y]
    plt.bar(x, y, color=c)

    mng = plt.get_current_fig_manager()
    # mng.frame.Maximize(True)
    # mng.window.showMaximized()
    # mng.full_screen_toggle()
    mng.window.state('zoomed')
    plt.show()
except Exception as e:
    print(e)
