# -*- coding: utf-8 -*-

import sqlite3
import sys

import constants

def get_stock_name(code):
    """
    get stock name of the code
    :param code: stock code
    :return: stock name
    """

    conn = sqlite3.connect('{0}/stocks.db'.format(constants.data_dir))
    try:
        cu = conn.cursor()
        cu.execute("select `name` from stocks where symbol='%s'" % code)
        r = cu.fetchone()
        if r is not None and len(r) > 0:
            return r[0]
        else:
            return constants.index_dict.get(code)
    finally:
        if conn is not None:
            conn.close()


if __name__ == "__main__":
    code = 'sh000001'
    if len(sys.argv) > 1:
        code = sys.argv[1]

    print("%s: %s" % (code, get_stock_name(code)))
