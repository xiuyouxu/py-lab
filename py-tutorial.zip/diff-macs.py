# -*- coding: utf-8 -*-

# 按行将文件内容读取到一个集合中
def read2set(file):
    f = open(file, 'r')
    r = []
    try:
        while True:
            line = f.readline()
            if line:
                r.append(line)
            else:
                print("file EOF:", file)
                break
    finally:
        f.close()

    return set(r)


all = read2set('./online-devices.csv')
online = read2set('devicecode.txt')

offline = online.difference(all)
print(offline)
