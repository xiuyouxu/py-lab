# -*- coding: utf-8 -*-

import datetime

d = datetime.datetime.strptime('2019-08-07', '%Y-%m-%d')
print(d.date())
print(d.date() == datetime.date.today())

print("{} good, {} ok".format(1, 2))
